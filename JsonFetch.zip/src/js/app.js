const ul = document.getElementById('authors')
const url = 'https://jsonplaceholder.typicode.com/users'



function createNode(element){
    return document.createElement(element);
}

function append(parent,element){
    return parent.appendChild(element);
}

function display(object){
    for (let user of object) {
        let placeholder = createNode('LI');
        console.log(user.name)
        placeholder.textContent = user.name;
        
        append(ul,placeholder);
    }

}

fetch(url)
.then(response => response.json())
.then (users => display(users))
.catch(error => error.log(error));

// fetch("https://jsonplaceholder.typicode.com/users")
// .then(response => response.json())
// .then(users=>console.log(users))
// .catch(error=>document.getElementById("out").textContent=error);


// function showUsers(users) {
//     var str = "";
//     for(let user of users) {
//       str += user.name + ", " + user.email + "\n"
//     }
//     document.getElementById("out").textContent = str;
//   }
  