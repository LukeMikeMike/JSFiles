let dataBase = [];
document.getElementById('btn1').addEventListener('click', function addPerson(){
    let sex = document.getElementById('sex').value;
    let height = document.getElementById('height').value;
    let DOB = document.getElementById('DOB').value;
    dataBase.push (new Person(sex,height,DOB))
    console.log(dataBase);
})


document.getElementById('btn4').addEventListener('click', function addDog(){
    let sex = document.getElementById('sex').value;
    let height = document.getElementById('height').value;
    let DOB = document.getElementById('DOB').value;
    let barkingSound = document.getElementById('barkingSound').value;
    dataBase.push (new Dog(sex,height,DOB,barkingSound))
    console.log(dataBase);
})

document.getElementById('btn2').addEventListener('click', function printDataBase(){
    for (var i=0; i<dataBase.length; ++i) {
        let output = document.querySelector('H1')
        output.innerText += `Płeć ${dataBase[i].sex} wzrost: ${dataBase[i].height} DOB:${dataBase[i].DOB}`;
        if (dataBase[i].barkingSound){
            output.innerText += `Barking Sound ${dataBase[i].barkingSound}`
        }
    }
})

class Person{
    constructor (sex,height,DOB){
        this.sex = sex;
        this.height = height;
        this.DOB = DOB;
    }
    printSex(){
        return `Płeć: ${this.sex}`;
    }
    printHeight(){
        return `Wzrost: ${this.height}`;
    }
    printDOB(){
        return `Data Urodzenia: ${this.DOB}`;
    }
}
// function getInput(){
// document.getElementById('sex').va
// }

class Dog extends Person {
     constructor(sex,height,DOB,barkingSound) {
         super (sex,height,DOB);
         this.barkingSound = barkingSound;
     }  



}
// class Motocycle extends Vehicle {
    //     constructor(vehicleType, color){
    //         super(vehicleType, color)
    //         this.engineType = 'gas';
    //     }

// let counter = 0;
// // let car = [];
// // document.getElementById('btn1').addEventListener('click', function buildVehicle(){
// // let vehicleType = document.getElementById('made').value
// // let color = document.getElementById('color').value
// // let engine = document.getElementById('engine').value
// // console.log (vehicleType, color, engine);
// // car[counter] = new Vehicle(vehicleType, color, engine); 
// // console.log (car[counter]);
// // counter++;
// // });

// class Vehicle {
//     constructor (vehicleType, color, engineType){
//         this.vehicleType = vehicleType;
//         this.color = color;
//         this.engineType = engineType;
//         this.odometer = 0;
//     }

//     writeType() {
//         return `Samochd marki ${this.wehicleType}`
//     }

//     writeColor() {
//         return `Kolor pojazdu to: ${this.color}`;
        
//     }
//     writeEngine() {
//         if (this.engineType === 'electric') {
//             return `${this.engineType} is green`    
//         }
//         if (this.engineType === 'deisel' || 'gas') {
//             return `${this.engineType} isn't green , Elon Musk would be disapointed`
//         }
//         else {return `wrong engine type`}
//     }

//     odometerWrite(number){
//         if (number === undefined){number = 0};
//         console.log(number);
//     let odometerCount = Math.floor((Math.random() * 10000) + 1000);
//     odometerCount = Math.round(odometerCount/100)*100;
//     odometerCount += number; //dodanty element
//     this.odometer = odometerCount;
//     if (odometerCount > 2500) {
//         return odometerCount;
//     }
//     else return `silnik jest niedotarty`;
//     }
    
//     writetoHTML(obj) {
//         let div = document.querySelector('H1');
//         div.textContent += `Manufacturer: ${obj.vehicleType} Color: ${obj.color} Engine Type: ${obj.engineType} Odometer: ${obj.odometer}`;

//     }
   
// }

// class Motocycle extends Vehicle {
//     constructor(vehicleType, color){
//         super(vehicleType, color)
//         this.engineType = 'gas';
//     }
//      writeHTMLMotorcycle() {
//     let div = document.querySelector('H2');
//     div.textContent = `It's a two wheel vehicle`
//     }

//     //podumać

//     // writeWheelNumber() {

//     // }
// }

// class Car extends Vehicle {
//     constructor (vehicleType, color, engineType){
//         super(vehicleType, color, engineType) 

//     }
//     carWrite(){
//         const temp = `The car is indestructible because it's ${this.color}`;
//         console.log(temp);
//     }

//     odometerModify(number) {
//         const newValue = number;
//         super.odometerWrite(number);
//     }
    
// }

// class Garage {
//     constructor(){
//         this.obsoleteText = `vehicle list`;
//         this.vehicleList = []
//         console.log (this.vehicleList);
//     }
// addVehicleGarage(obj){
//     document.getElementById('btn1').addEventListener('click', function buildVehicle(){
//         let vehicleType = document.getElementById('made').value
//         let color = document.getElementById('color').value
//         let engine = document.getElementById('engine').value
//         obj.vehicleList[counter] =  new Vehicle(vehicleType, color, engine); 
//         console.log(obj.vehicleList[counter]);
//         // console.log (vehicleType, color, engine);
//         // arraaa[0] = new Vehicle(vehicleType, color, engine); 
//         counter++;
//         console.log(obj.vehicleList.length);
//         obj.garageWrite(obj);
//         // obj.writetoHTMLArr(obj.vehicleList);
// })
// }
// garageWrite(obj){
//     let div1 = document.querySelector('H1');
//     for (var i=0; i<obj.vehicleList.length; ++i){
//         div1.textContent += obj.vehicleList[i].vehicleType
//         div1.textContent += obj.vehicleList[i].color
//         div1.textContent += obj.vehicleList[i].engine
//         //this 
//     }

// }
// // writetoHTMLArr(obj) {
// //     let div = document.querySelector('H1');
// //     for (var i=0; i<5; ++i){
// //         div.textContent += obj.vehicleList[i];
// //     } 
// // }
// }

// // let car01 = new Vehicle('VW', 'green', 'electric');
// // console.log(car01);
// // console.log(car01.writeEngine());
// // console.log(car01.odometerWrite());
// // car01.odometerWrite();
// // console.log(car01.odometer);

// // car01.odometerWrite();
// // car01.writetoHTMLodometer(car01);

// //  let motocycle01 = new Motocycle('Harley Davidson', 'black');
// // // console.log(motocycle01);
// // // console.log(motocycle01.odometerWrite());
// // // console.log(motocycle01);
// // // motocycle01.writeHTMLMotorcycle();

// // let car02 = new Car('Peugeot', 'yellow', 'diesel');
// // car02.odometerWrite();
// // console.log(car02);
// // car02.odometerModify(100000);
// // console.log(car02);
// // car02.writetoHTML(car02);
// // motocycle01.writetoHTML(motocycle01);

// let garage1 = new Garage;
// // console.log(garage1.vehicleList);
// // garage1.vehicleList[0] = 1234;
// // garage1.addVehicleGarage();
// // console.log(garage1);
// garage1.addVehicleGarage(garage1);
// // console.log(garage1.vehicleList);
// garage1.garageWrite(garage1);

