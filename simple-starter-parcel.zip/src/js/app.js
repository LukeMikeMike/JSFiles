import Foo from './test';

(() => {
    'use strict';

    const testVar = new Foo();
    testVar.speak();

    console.log('test');
})();
