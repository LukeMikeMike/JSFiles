class Foo {
    constructor() {
        
    }
    speak() {
        console.log('speak')
    }
};

export default Foo;